import AdminShell from '../components/AdminShell';

function AdminMetricCard({ label, value }) {
  return (
    <article className="admin-metric-card">
      <strong>{label}</strong>
      <span>{value}</span>
    </article>
  );
}

export default function AdminDashboardPage({ navigate, products }) {
  return (
    <AdminShell title="Admin Dashboard" current="admin-dashboard" navigate={navigate}>
      <div className="admin-metrics">
        <AdminMetricCard label="Total Sales" value="$12,430" />
        <AdminMetricCard label="Total Users" value="1,280" />
        <AdminMetricCard label="Total Products" value={products.length || 352} />
        <AdminMetricCard label="Pending Refunds" value="8" />
      </div>

      <section className="admin-chart-card">
        <div className="admin-chart-bars" aria-hidden="true">
          {[46, 62, 58, 74, 68, 84, 78].map((height, index) => (
            <span style={{ height: `${height}%` }} key={index} />
          ))}
        </div>
        <strong>Sales Overview Chart</strong>
      </section>

      <section className="admin-panel">
        <div className="admin-panel-heading">
          <span className="eyebrow">Recent activity</span>
          <h2>Recent orders</h2>
        </div>
        <div className="admin-table admin-dashboard-table">
          <div className="admin-table-row admin-table-head">
            <strong>Order ID</strong>
            <strong>User</strong>
            <strong>Total</strong>
            <strong>Status</strong>
            <strong>Action</strong>
          </div>
          <div className="admin-table-row">
            <span>ORD-1001</span>
            <span>U1001</span>
            <span>$39.98</span>
            <span><em className="status-paid">Paid</em></span>
            <button type="button">View</button>
          </div>
          <div className="admin-table-row">
            <span>ORD-1002</span>
            <span>U1002</span>
            <span>$9.99</span>
            <span><em className="status-warning">Refund Requested</em></span>
            <button type="button" onClick={() => navigate('admin-refund-management')}>Review</button>
          </div>
        </div>
      </section>
    </AdminShell>
  );
}
