import { useState } from 'react';
import AdminShell from '../components/AdminShell';
import { adminRefunds } from '../config/adminData';

export default function AdminRefundManagementPage({ navigate }) {
  const [selectedRefund, setSelectedRefund] = useState(adminRefunds[0]);
  const [decision, setDecision] = useState('Allow Refund');

  return (
    <AdminShell title="Admin Refund Management | Current: Refunds" current="admin-refund-management" navigate={navigate}>
      <div className="admin-section-label">Refund Requests</div>
      <div className="admin-filter-bar">
        <label>Search Order ID <input aria-label="Search order ID" /></label>
        <label>Status <select defaultValue="Pending"><option>Pending</option><option>Approved</option><option>Rejected</option></select></label>
        <label>Date <input type="date" aria-label="Start date" /></label>
        <button type="button">Search</button>
      </div>

      <div className="admin-table admin-refund-table">
        <div className="admin-table-row admin-table-head">
          <strong>Refund ID</strong>
          <strong>Order ID</strong>
          <strong>User ID</strong>
          <strong>Reason</strong>
          <strong>Amount</strong>
          <strong>Status</strong>
          <strong>Action</strong>
        </div>
        {adminRefunds.map((refund) => (
          <div className="admin-table-row" key={refund.id}>
            <span>{refund.id}</span>
            <span>{refund.orderId}</span>
            <span>{refund.userId}</span>
            <span>{refund.reason}</span>
            <span>${refund.amount.toFixed(2)}</span>
            <span><em className={refund.status === 'Pending' ? 'status-warning' : 'status-paid'}>{refund.status}</em></span>
            <button type="button" onClick={() => setSelectedRefund(refund)}>Review</button>
          </div>
        ))}
      </div>

      <div className="admin-section-label">Refund Review Detail</div>
      <section className="admin-panel admin-detail-panel">
        <div className="admin-detail-grid">
          <span><small>Refund ID</small><strong>{selectedRefund.id}</strong></span>
          <span><small>Order ID</small><strong>{selectedRefund.orderId}</strong></span>
          <span><small>Refund Person ID</small><strong>{selectedRefund.userId}</strong></span>
          <span><small>Product ID</small><strong>{selectedRefund.productId}</strong></span>
          <span><small>Refund Reason</small><strong>{selectedRefund.reason}</strong></span>
          <span><small>Product Usage Status</small><strong>{selectedRefund.usage}</strong></span>
          <span><small>Payment Status</small><strong>{selectedRefund.paymentStatus}</strong></span>
          <span><small>Refund Amount</small><strong>${selectedRefund.amount.toFixed(2)}</strong></span>
        </div>
        <div className="admin-decision-box">
          <strong>Admin Decision</strong>
          <label><input type="radio" name="refundDecision" checked={decision === 'Allow Refund'} onChange={() => setDecision('Allow Refund')} /> Allow Refund</label>
          <label><input type="radio" name="refundDecision" checked={decision === 'Reject Refund'} onChange={() => setDecision('Reject Refund')} /> Reject Refund</label>
          <label className="admin-wide-field">Admin Note <textarea rows="3" placeholder="Add review note" /></label>
          <button className="primary-button" type="button">Submit Decision</button>
        </div>
      </section>
    </AdminShell>
  );
}
