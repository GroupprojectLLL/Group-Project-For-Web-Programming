import { useState } from 'react';
import AdminShell from '../components/AdminShell';
import { adminUsers } from '../config/adminData';

export default function AdminUserManagementPage({ navigate }) {
  const [selectedUser, setSelectedUser] = useState(adminUsers[0]);

  return (
    <AdminShell title="Admin User Management | Current: Users" current="admin-user-management" navigate={navigate}>
      <div className="admin-section-label">User List</div>
      <div className="admin-filter-bar">
        <label>Search User <input aria-label="Search user" /></label>
        <label>Status <select defaultValue="All"><option>All</option><option>Active</option><option>Suspended</option></select></label>
        <label>Role <select defaultValue="Customer/Admin"><option>Customer/Admin</option><option>Customer</option><option>Admin</option></select></label>
        <button type="button">Search</button>
      </div>

      <div className="admin-table admin-user-table">
        <div className="admin-table-row admin-table-head">
          <strong>User ID</strong>
          <strong>Name</strong>
          <strong>Email</strong>
          <strong>Role</strong>
          <strong>Status</strong>
          <strong>Orders</strong>
          <strong>Actions</strong>
        </div>
        {adminUsers.map((adminUser) => (
          <div className="admin-table-row" key={adminUser.id}>
            <span>{adminUser.id}</span>
            <span>{adminUser.name}</span>
            <span>{adminUser.email}</span>
            <span>{adminUser.role}</span>
            <span><em className={adminUser.status === 'Active' ? 'status-paid' : 'status-warning'}>{adminUser.status}</em></span>
            <span>{adminUser.orders}</span>
            <span className="admin-row-actions">
              <button type="button" onClick={() => setSelectedUser(adminUser)}>View</button>
              <button type="button">{adminUser.status === 'Active' ? 'Disable' : 'Enable'}</button>
            </span>
          </div>
        ))}
      </div>

      <div className="admin-section-label">User Detail Panel</div>
      <section className="admin-panel admin-detail-panel">
        <div className="admin-detail-grid">
          <span><small>User ID</small><strong>{selectedUser.id}</strong></span>
          <span><small>Name</small><strong>{selectedUser.name}</strong></span>
          <span><small>Email</small><strong>{selectedUser.email}</strong></span>
          <span><small>Status</small><strong>{selectedUser.status}</strong></span>
          <span><small>Registered Date</small><strong>{selectedUser.registered}</strong></span>
          <span><small>Total Orders</small><strong>{selectedUser.orders}</strong></span>
          <span><small>Total Spending</small><strong>${selectedUser.spending.toFixed(2)}</strong></span>
          <span><small>Refund Count</small><strong>{selectedUser.refunds}</strong></span>
        </div>
        <div className="admin-form-actions">
          <button className="primary-button" type="button" onClick={() => navigate('order-history')}>View Orders</button>
          <button type="button">{selectedUser.status === 'Active' ? 'Disable User' : 'Enable User'}</button>
          <button type="button">Reset Password Link</button>
        </div>
      </section>
    </AdminShell>
  );
}
