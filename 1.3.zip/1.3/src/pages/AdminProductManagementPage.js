import { useState } from 'react';
import ProductArt from '../components/ProductArt';
import { products as demoProducts } from '../data';
import AdminShell from '../components/AdminShell';

export default function AdminProductManagementPage({ navigate, products }) {
  const adminProducts = (products.length ? products : demoProducts).slice(0, 4);
  const [selectedProduct, setSelectedProduct] = useState(adminProducts[0]);

  return (
    <AdminShell title="Admin Product Management | Current: Products" current="admin-product-management" navigate={navigate}>
      <div className="admin-section-label">Product List</div>
      <div className="admin-filter-bar">
        <label>Search Product <input aria-label="Search product" /></label>
        <label>Category <select defaultValue="All"><option>All</option><option>E-books</option><option>Games</option><option>Movies & TV</option></select></label>
        <label>Status <select defaultValue="All"><option>All</option><option>Active</option><option>Hidden</option></select></label>
        <button type="button">Add New Product</button>
      </div>

      <div className="admin-table admin-product-table">
        <div className="admin-table-row admin-table-head">
          <strong>ID</strong>
          <strong>Cover</strong>
          <strong>Title</strong>
          <strong>Category</strong>
          <strong>Price</strong>
          <strong>Status</strong>
          <strong>Actions</strong>
        </div>
        {adminProducts.map((product, index) => (
          <div className="admin-table-row" key={product.id}>
            <span>P{String(product.id || index + 101).padStart(3, '0')}</span>
            <ProductArt product={product} className="admin-cover" />
            <span>{product.title}</span>
            <span>{product.category}</span>
            <span>${Number(product.price || 0).toFixed(2)}</span>
            <span><em className="status-paid">Active</em></span>
            <span className="admin-row-actions">
              <button type="button" onClick={() => setSelectedProduct(product)}>View</button>
              <button type="button" onClick={() => setSelectedProduct(product)}>Edit</button>
              <button type="button">Delete</button>
            </span>
          </div>
        ))}
      </div>

      <div className="admin-section-label">Add / Edit Product Form</div>
      <section className="admin-panel admin-form-panel" key={selectedProduct?.id}>
        <div className="admin-form-grid">
          <label>Product Title <input defaultValue={selectedProduct?.title || ''} /></label>
          <label>Category <select defaultValue={selectedProduct?.category || 'Games'}><option>E-books</option><option>Games</option><option>Movies & TV</option></select></label>
          <label>Price <input defaultValue={Number(selectedProduct?.price || 0).toFixed(2)} /></label>
          <label>Status <select defaultValue="Active"><option>Active</option><option>Hidden</option></select></label>
          <label>Cover Image <input placeholder="Upload or paste image URL" /></label>
          <label>Digital File / Access Link <input placeholder="Upload or URL" /></label>
          <label className="admin-wide-field">Description <textarea defaultValue={selectedProduct?.description || ''} rows="4" /></label>
        </div>
        <div className="admin-note-list">
          <span>Book Fields: Author / Publisher / Format</span>
          <span>Game Fields: Developer / Platform / System Requirements</span>
          <span>Movie Fields: Director / Duration / Resolution</span>
        </div>
        <div className="admin-form-actions">
          <button className="primary-button" type="button">Save Product</button>
          <button type="button">Cancel</button>
          <button type="button">Delete Product</button>
        </div>
      </section>
    </AdminShell>
  );
}
