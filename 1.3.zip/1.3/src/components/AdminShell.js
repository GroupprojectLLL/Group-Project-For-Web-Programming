import Icon from './Icon';
import { adminMenuItems } from '../config/adminData';

export default function AdminShell({ title, current, navigate, children }) {
  return (
    <main className="admin-page page-shell">
      <div className="admin-titlebar">{title}</div>

      <section className="admin-topbar">
        <button className="admin-logo" type="button" onClick={() => navigate('admin-dashboard')}>Admin Logo</button>
        <strong>Admin Panel</strong>
        <label className="admin-search">
          <Icon name="search" size={16} />
          <input placeholder="Search" aria-label="Search admin records" />
        </label>
        <button className="admin-account" type="button" onClick={() => navigate('account')}>Admin Account</button>
      </section>

      <div className="admin-layout">
        <aside className="admin-sidebar">
          <span>Side Menu</span>
          <div>
            {adminMenuItems.map((item) => (
              <button
                className={current === item.page ? 'active' : ''}
                type="button"
                onClick={() => navigate(item.page)}
                key={item.label}
              >
                {item.label}
              </button>
            ))}
            <button type="button" onClick={() => navigate('home')}>Logout</button>
          </div>
        </aside>

        <section className="admin-content">
          {children}
        </section>
      </div>
    </main>
  );
}
