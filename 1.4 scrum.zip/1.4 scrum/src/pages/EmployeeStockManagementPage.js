import { useMemo, useState } from 'react';
import EmployeeShell from '../components/EmployeeShell';
import { getStockStatus } from '../config/employeeData';

export default function EmployeeStockManagementPage({ navigate, inventory, onUpdateInventory }) {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [status, setStatus] = useState('All');
  const [selectedId, setSelectedId] = useState(inventory[0]?.id || '');
  const [quantity, setQuantity] = useState('');
  const [reason, setReason] = useState('');
  const [message, setMessage] = useState('');
  const selected = inventory.find((item) => item.id === selectedId) || inventory[0];

  const filtered = useMemo(() => {
    const query = search.trim().toLowerCase();
    return inventory.filter((item) => (
      (!query || [item.id, item.sku, item.product].some((value) => value.toLowerCase().includes(query)))
      && (category === 'All' || item.category === category)
      && (status === 'All' || getStockStatus(item) === status)
    ));
  }, [category, inventory, search, status]);

  function chooseItem(item) {
    setSelectedId(item.id);
    setQuantity(String(item.available));
    setReason('');
    setMessage('');
  }

  function saveStock() {
    const nextQuantity = Number(quantity);
    if (!Number.isInteger(nextQuantity) || nextQuantity < 0) {
      setMessage('Please enter a whole number of zero or more.');
      return;
    }
    if (!reason.trim()) {
      setMessage('Please provide a reason for the stock change.');
      return;
    }
    onUpdateInventory(selected.id, nextQuantity, reason.trim());
    setMessage(`${selected.product} stock updated to ${nextQuantity}.`);
    setReason('');
  }

  return (
    <EmployeeShell title="Stock Management" current="employee-stock-management" navigate={navigate} searchValue={search} onSearchChange={setSearch}>
      <div className="employee-section-label">Available Store Items</div>
      <div className="employee-filter-bar">
        <label>Category <select value={category} onChange={(event) => setCategory(event.target.value)} aria-label="Inventory category"><option>All</option><option>Games</option><option>Books</option><option>Movies & TV</option></select></label>
        <label>Status <select value={status} onChange={(event) => setStatus(event.target.value)} aria-label="Inventory status"><option>All</option><option>Available</option><option>Low Stock</option><option>Out of Stock</option></select></label>
        <button type="button" onClick={() => { setSearch(''); setCategory('All'); setStatus('All'); }}>Clear Filters</button>
        <span>{filtered.length} result{filtered.length === 1 ? '' : 's'}</span>
      </div>

      <div className="employee-table employee-stock-table" aria-label="Employee stock table">
        <div className="employee-table-row employee-table-head"><strong>Stock ID</strong><strong>SKU</strong><strong>Product</strong><strong>Category</strong><strong>Available</strong><strong>Reserved</strong><strong>Status</strong><strong>Action</strong></div>
        {filtered.map((item) => (
          <div className={`employee-table-row ${selected?.id === item.id ? 'is-selected' : ''}`} key={item.id}>
            <span>{item.id}</span><span>{item.sku}</span><strong>{item.product}</strong><span>{item.category}</span><span>{item.available}</span><span>{item.reserved}</span>
            <em className={item.available === 0 ? 'stock-out' : item.available <= item.reorderLevel ? 'stock-low' : 'stock-ok'}>{getStockStatus(item)}</em>
            <button type="button" onClick={() => chooseItem(item)}>Adjust</button>
          </div>
        ))}
        {!filtered.length && <div className="employee-empty-row">No stock items match the current filters.</div>}
      </div>

      {selected && (
        <section className="employee-panel employee-adjust-panel">
          <div><span className="eyebrow">Adjust inventory</span><h2>{selected.product}</h2><p>{selected.sku} · Current available quantity: {selected.available}</p></div>
          <div className="employee-adjust-form">
            <label>New Available Quantity <input type="number" min="0" step="1" value={quantity} onChange={(event) => setQuantity(event.target.value)} aria-label="New available quantity" /></label>
            <label>Reason <textarea rows="3" value={reason} onChange={(event) => setReason(event.target.value)} placeholder="Why is the stock changing?" /></label>
            {message && <div className={`employee-message ${message.startsWith('Please') ? 'is-error' : ''}`} role="status">{message}</div>}
            <button className="primary-button" type="button" onClick={saveStock}>Save Stock Change</button>
          </div>
        </section>
      )}
    </EmployeeShell>
  );
}
