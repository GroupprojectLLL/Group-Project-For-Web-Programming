import { fireEvent, render, screen, within } from '@testing-library/react';
import EmployeeDashboardPage from './EmployeeDashboardPage';
import EmployeeStockManagementPage from './EmployeeStockManagementPage';
import EmployeeStockHistoryPage from './EmployeeStockHistoryPage';
import { initialInventory, initialStockHistory } from '../config/employeeData';

describe('Employee Portal', () => {
  test('shows live inventory metrics and stock alerts', () => {
    render(<EmployeeDashboardPage navigate={jest.fn()} inventory={initialInventory} />);

    expect(screen.getByText('58')).toBeInTheDocument();
    expect(screen.getByText('Pixel Kitchen')).toBeInTheDocument();
    expect(screen.getByText('Out of Stock', { selector: '.employee-alert-table em' })).toBeInTheDocument();
  });

  test('filters stock and submits a valid stock adjustment', () => {
    const onUpdateInventory = jest.fn();
    render(<EmployeeStockManagementPage navigate={jest.fn()} inventory={initialInventory} onUpdateInventory={onUpdateInventory} />);

    fireEvent.change(screen.getByLabelText('Inventory status'), { target: { value: 'Out of Stock' } });
    const table = screen.getByLabelText('Employee stock table');
    expect(within(table).getByText('Pixel Kitchen')).toBeInTheDocument();
    expect(within(table).queryByText('Nebula Drift')).not.toBeInTheDocument();

    fireEvent.click(within(table).getByRole('button', { name: 'Adjust' }));
    fireEvent.change(screen.getByLabelText('New available quantity'), { target: { value: '15' } });
    fireEvent.change(screen.getByPlaceholderText('Why is the stock changing?'), { target: { value: 'New licence batch' } });
    fireEvent.click(screen.getByRole('button', { name: 'Save Stock Change' }));

    expect(onUpdateInventory).toHaveBeenCalledWith('STK-103', 15, 'New licence batch');
  });

  test('shows searchable stock movement history', () => {
    render(<EmployeeStockHistoryPage navigate={jest.fn()} history={initialStockHistory} />);

    fireEvent.change(screen.getByLabelText('Search employee records'), { target: { value: 'licence' } });
    const table = screen.getByLabelText('Stock history table');
    expect(within(table).getByText('The Quiet Archive')).toBeInTheDocument();
    expect(within(table).queryByText('Solar Tactics')).not.toBeInTheDocument();
  });
});
