import { fireEvent, render, screen } from '@testing-library/react';
import AccountPage from './AccountPage';

describe('Account role routing', () => {
  test('routes an employee to the employee dashboard', () => {
    const navigate = jest.fn();
    const onAuth = jest.fn();
    render(<AccountPage products={[]} onAuth={onAuth} checkoutPending={false} navigate={navigate} />);

    const roleSelect = screen.getByLabelText('Demo role');
    expect(roleSelect.closest('.form-field')).toHaveTextContent('Continue to workspace');
    expect(roleSelect.closest('.form-field')).toHaveTextContent('Demo only');
    fireEvent.change(roleSelect, { target: { value: 'Employee' } });
    fireEvent.submit(roleSelect.closest('form'));

    expect(onAuth).toHaveBeenCalledWith(expect.objectContaining({ role: 'Employee' }));
    expect(navigate).toHaveBeenCalledWith('employee-dashboard');
  });

  test('routes an admin to the admin dashboard', () => {
    const navigate = jest.fn();
    render(<AccountPage products={[]} onAuth={jest.fn()} checkoutPending={false} navigate={navigate} />);

    const roleSelect = screen.getByLabelText('Demo role');
    fireEvent.change(roleSelect, { target: { value: 'Admin' } });
    fireEvent.submit(roleSelect.closest('form'));

    expect(navigate).toHaveBeenCalledWith('admin-dashboard');
  });
});
