import EmployeeShell from '../components/EmployeeShell';
import { getStockStatus } from '../config/employeeData';

export default function EmployeeDashboardPage({ navigate, inventory }) {
  const totalAvailable = inventory.reduce((sum, item) => sum + item.available, 0);
  const lowStock = inventory.filter((item) => getStockStatus(item) === 'Low Stock');
  const outOfStock = inventory.filter((item) => getStockStatus(item) === 'Out of Stock');
  const needsAttention = [...outOfStock, ...lowStock];

  return (
    <EmployeeShell title="Inventory Dashboard" current="employee-dashboard" navigate={navigate}>
      <div className="employee-metrics" aria-label="Inventory summary">
        <article><span>Stock Items</span><strong>{inventory.length}</strong><small>Tracked products</small></article>
        <article><span>Units Available</span><strong>{totalAvailable}</strong><small>Ready for sale</small></article>
        <article><span>Low Stock</span><strong>{lowStock.length}</strong><small>Reorder soon</small></article>
        <article><span>Out of Stock</span><strong>{outOfStock.length}</strong><small>Immediate attention</small></article>
      </div>

      <section className="employee-panel">
        <div className="employee-panel-heading">
          <div><span className="eyebrow">Action required</span><h2>Stock alerts</h2></div>
          <button type="button" onClick={() => navigate('employee-stock-management')}>Manage all stock</button>
        </div>
        <div className="employee-table employee-alert-table">
          <div className="employee-table-row employee-table-head"><strong>SKU</strong><strong>Product</strong><strong>Available</strong><strong>Reorder Level</strong><strong>Status</strong><strong>Action</strong></div>
          {needsAttention.map((item) => (
            <div className="employee-table-row" key={item.id}>
              <span>{item.sku}</span><strong>{item.product}</strong><span>{item.available}</span><span>{item.reorderLevel}</span>
              <em className={item.available === 0 ? 'stock-out' : 'stock-low'}>{getStockStatus(item)}</em>
              <button type="button" onClick={() => navigate('employee-stock-management')}>Update</button>
            </div>
          ))}
        </div>
      </section>
    </EmployeeShell>
  );
}
