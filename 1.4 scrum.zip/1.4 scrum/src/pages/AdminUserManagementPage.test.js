import { fireEvent, render, screen, within } from '@testing-library/react';
import AdminUserManagementPage from './AdminUserManagementPage';

describe('AdminUserManagementPage', () => {
  test('filters users by search, status and role', () => {
    render(<AdminUserManagementPage navigate={jest.fn()} />);

    fireEvent.change(screen.getByLabelText('User status'), { target: { value: 'Active' } });
    fireEvent.change(screen.getByLabelText('User role'), { target: { value: 'Admin' } });

    const table = screen.getByLabelText('User list table');
    expect(within(table).getByText('U1003')).toBeInTheDocument();
    expect(within(table).queryByText('U1001')).not.toBeInTheDocument();
    expect(screen.getByText('1 result')).toBeInTheDocument();
  });

  test('disables and enables a user', () => {
    render(<AdminUserManagementPage navigate={jest.fn()} />);

    const table = screen.getByLabelText('User list table');
    const row = within(table).getByText('U1001').closest('.admin-table-row');
    fireEvent.click(within(row).getByRole('button', { name: 'Disable' }));

    expect(within(row).getByText('Suspended')).toBeInTheDocument();
    expect(screen.getByRole('status')).toHaveTextContent('Monet is now suspended');
    expect(within(row).getByRole('button', { name: 'Enable' })).toBeInTheDocument();
  });

  test('reports that a password reset link was sent', () => {
    render(<AdminUserManagementPage navigate={jest.fn()} />);

    fireEvent.click(screen.getByRole('button', { name: 'Send Reset Password Link' }));

    expect(screen.getByRole('status')).toHaveTextContent('user1@email.com');
  });
});
