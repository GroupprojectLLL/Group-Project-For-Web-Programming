import { useState } from 'react';
import EmployeeShell from '../components/EmployeeShell';

export default function EmployeeStockHistoryPage({ navigate, history }) {
  const [search, setSearch] = useState('');
  const query = search.trim().toLowerCase();
  const rows = history.filter((entry) => !query || [entry.stockId, entry.product, entry.reason, entry.employee].some((value) => value.toLowerCase().includes(query)));

  return (
    <EmployeeShell title="Stock History" current="employee-stock-history" navigate={navigate} searchValue={search} onSearchChange={setSearch} searchPlaceholder="Search stock history">
      <div className="employee-section-label">Inventory Movement Log</div>
      <div className="employee-table employee-history-table" aria-label="Stock history table">
        <div className="employee-table-row employee-table-head"><strong>Time</strong><strong>Stock ID</strong><strong>Product</strong><strong>Before</strong><strong>After</strong><strong>Change</strong><strong>Reason</strong><strong>Employee</strong></div>
        {rows.map((entry) => (
          <div className="employee-table-row" key={entry.id}>
            <span>{entry.timestamp}</span><span>{entry.stockId}</span><strong>{entry.product}</strong><span>{entry.before}</span><span>{entry.after}</span>
            <em className={entry.change >= 0 ? 'stock-increase' : 'stock-decrease'}>{entry.change > 0 ? '+' : ''}{entry.change}</em>
            <span>{entry.reason}</span><span>{entry.employee}</span>
          </div>
        ))}
        {!rows.length && <div className="employee-empty-row">No stock history matches your search.</div>}
      </div>
    </EmployeeShell>
  );
}
