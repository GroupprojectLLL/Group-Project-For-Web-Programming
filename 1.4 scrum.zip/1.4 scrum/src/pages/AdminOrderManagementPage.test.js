import { fireEvent, render, screen, within } from '@testing-library/react';
import AdminOrderManagementPage from './AdminOrderManagementPage';

describe('AdminOrderManagementPage', () => {
  test('filters orders by status and payment state', () => {
    render(<AdminOrderManagementPage navigate={jest.fn()} />);

    fireEvent.change(screen.getByLabelText('Order status filter'), { target: { value: 'On Hold' } });
    fireEvent.change(screen.getByLabelText('Payment status filter'), { target: { value: 'Pending' } });

    const table = screen.getByLabelText('Admin orders table');
    expect(within(table).getByText('ORD-1004')).toBeInTheDocument();
    expect(within(table).queryByText('ORD-1001')).not.toBeInTheDocument();
  });

  test('updates an order status and admin note', () => {
    render(<AdminOrderManagementPage navigate={jest.fn()} />);

    const table = screen.getByLabelText('Admin orders table');
    const processingRow = within(table).getByText('ORD-1003').closest('.admin-table-row');
    fireEvent.click(within(processingRow).getByRole('button', { name: 'Manage' }));
    fireEvent.change(screen.getByLabelText('Update order status'), { target: { value: 'Completed' } });
    fireEvent.change(screen.getByPlaceholderText('Internal note about this order'), {
      target: { value: 'Access delivered.' },
    });
    fireEvent.click(screen.getByRole('button', { name: 'Save Order' }));

    expect(within(processingRow).getByText('Completed')).toBeInTheDocument();
    expect(screen.getByRole('status')).toHaveTextContent('ORD-1003 has been updated');
  });

  test('opens refund management for a refund-requested order', () => {
    const navigate = jest.fn();
    render(<AdminOrderManagementPage navigate={navigate} />);

    const table = screen.getByLabelText('Admin orders table');
    const refundRow = within(table).getByText('ORD-1002').closest('.admin-table-row');
    fireEvent.click(within(refundRow).getByRole('button', { name: 'Manage' }));
    fireEvent.click(screen.getByRole('button', { name: 'Review Refund' }));

    expect(navigate).toHaveBeenCalledWith('admin-refund-management');
  });
});
