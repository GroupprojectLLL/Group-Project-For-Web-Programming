import { useMemo, useState } from 'react';
import AdminShell from '../components/AdminShell';
import { adminOrders } from '../config/adminData';

const ALL = 'All';
const ORDER_STATUSES = ['Processing', 'Completed', 'On Hold', 'Cancelled', 'Refund Requested', 'Refunded'];

function statusClass(status) {
  if (status === 'Completed') return 'status-paid';
  if (status === 'Cancelled' || status === 'Refunded') return 'status-rejected';
  return 'status-warning';
}

export default function AdminOrderManagementPage({ navigate }) {
  const [orders, setOrders] = useState(() => adminOrders.map((order) => ({
    ...order,
    items: order.items.map((item) => ({ ...item })),
  })));
  const [selectedOrderId, setSelectedOrderId] = useState(adminOrders[0]?.id || '');
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState(ALL);
  const [paymentFilter, setPaymentFilter] = useState(ALL);
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [draftStatus, setDraftStatus] = useState(adminOrders[0]?.fulfillmentStatus || 'Processing');
  const [adminNote, setAdminNote] = useState(adminOrders[0]?.adminNote || '');
  const [message, setMessage] = useState('');

  const selectedOrder = orders.find((order) => order.id === selectedOrderId) || orders[0];

  const filteredOrders = useMemo(() => {
    const query = search.trim().toLowerCase();

    return orders.filter((order) => {
      const matchesSearch = !query || [
        order.id,
        order.userId,
        order.customer,
        order.email,
        ...order.items.map((item) => item.title),
      ].some((value) => String(value || '').toLowerCase().includes(query));
      const matchesStatus = statusFilter === ALL || order.fulfillmentStatus === statusFilter;
      const matchesPayment = paymentFilter === ALL || order.paymentStatus === paymentFilter;
      const matchesFrom = !dateFrom || order.date >= dateFrom;
      const matchesTo = !dateTo || order.date <= dateTo;

      return matchesSearch && matchesStatus && matchesPayment && matchesFrom && matchesTo;
    });
  }, [dateFrom, dateTo, orders, paymentFilter, search, statusFilter]);

  const metrics = useMemo(() => ({
    revenue: orders
      .filter((order) => order.paymentStatus === 'Paid' && order.fulfillmentStatus !== 'Refunded')
      .reduce((sum, order) => sum + order.total, 0),
    orders: orders.length,
    processing: orders.filter((order) => order.fulfillmentStatus === 'Processing').length,
    attention: orders.filter((order) => ['On Hold', 'Refund Requested'].includes(order.fulfillmentStatus)).length,
  }), [orders]);

  function selectOrder(order) {
    setSelectedOrderId(order.id);
    setDraftStatus(order.fulfillmentStatus);
    setAdminNote(order.adminNote || '');
    setMessage('');
  }

  function clearFilters() {
    setSearch('');
    setStatusFilter(ALL);
    setPaymentFilter(ALL);
    setDateFrom('');
    setDateTo('');
  }

  function saveOrder() {
    if (!selectedOrder) return;

    setOrders((items) => items.map((order) => (
      order.id === selectedOrder.id
        ? { ...order, fulfillmentStatus: draftStatus, adminNote: adminNote.trim() }
        : order
    )));
    setMessage(`${selectedOrder.id} has been updated.`);
  }

  return (
    <AdminShell
      title="Admin Order Management | Current: Orders"
      current="admin-order-management"
      navigate={navigate}
      searchValue={search}
      onSearchChange={setSearch}
      searchPlaceholder="Search orders"
    >
      <div className="admin-order-summary" aria-label="Order summary">
        <article><span>Paid Revenue</span><strong>${metrics.revenue.toFixed(2)}</strong></article>
        <article><span>Total Orders</span><strong>{metrics.orders}</strong></article>
        <article><span>Processing</span><strong>{metrics.processing}</strong></article>
        <article><span>Needs Attention</span><strong>{metrics.attention}</strong></article>
      </div>

      <div className="admin-section-label">Orders</div>
      <div className="admin-filter-bar admin-order-filters">
        <label>
          Search
          <input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            aria-label="Search orders"
            placeholder="Order, user or product"
          />
        </label>
        <label>
          Order Status
          <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)} aria-label="Order status filter">
            <option>All</option>
            {ORDER_STATUSES.map((status) => <option key={status}>{status}</option>)}
          </select>
        </label>
        <label>
          Payment
          <select value={paymentFilter} onChange={(event) => setPaymentFilter(event.target.value)} aria-label="Payment status filter">
            <option>All</option>
            <option>Paid</option>
            <option>Pending</option>
            <option>Failed</option>
          </select>
        </label>
        <label>
          From
          <input
            value={dateFrom}
            onChange={(event) => setDateFrom(event.target.value)}
            aria-label="Orders from date"
            placeholder="YYYY-MM-DD"
            maxLength="10"
          />
        </label>
        <label>
          To
          <input
            value={dateTo}
            onChange={(event) => setDateTo(event.target.value)}
            aria-label="Orders to date"
            placeholder="YYYY-MM-DD"
            maxLength="10"
          />
        </label>
        <button type="button" onClick={clearFilters}>Clear Filters</button>
        <span className="admin-result-count">{filteredOrders.length} result{filteredOrders.length === 1 ? '' : 's'}</span>
      </div>

      <div className="admin-table admin-order-table" aria-label="Admin orders table">
        <div className="admin-table-row admin-table-head">
          <strong>Order</strong>
          <strong>Date</strong>
          <strong>Customer</strong>
          <strong>Items</strong>
          <strong>Total</strong>
          <strong>Payment</strong>
          <strong>Status</strong>
          <strong>Action</strong>
        </div>
        {filteredOrders.map((order) => (
          <div
            className={`admin-table-row ${selectedOrder?.id === order.id ? 'is-selected' : ''}`}
            key={order.id}
          >
            <strong>{order.id}</strong>
            <span>{order.date}</span>
            <span className="admin-customer-cell"><strong>{order.customer}</strong><small>{order.email}</small></span>
            <span>{order.items.reduce((sum, item) => sum + item.quantity, 0)}</span>
            <span>${order.total.toFixed(2)}</span>
            <span><em className={order.paymentStatus === 'Paid' ? 'status-paid' : 'status-warning'}>{order.paymentStatus}</em></span>
            <span><em className={statusClass(order.fulfillmentStatus)}>{order.fulfillmentStatus}</em></span>
            <button type="button" onClick={() => selectOrder(order)}>Manage</button>
          </div>
        ))}
        {!filteredOrders.length && <div className="admin-empty-row">No orders match the current filters.</div>}
      </div>

      {selectedOrder && (
        <>
          <div className="admin-section-label">Order Detail</div>
          <section className="admin-panel admin-order-detail">
            <div className="admin-review-heading">
              <div>
                <span className="eyebrow">Selected order</span>
                <h2>{selectedOrder.id}</h2>
                <p>{selectedOrder.date} · {selectedOrder.customer}</p>
              </div>
              <em className={statusClass(selectedOrder.fulfillmentStatus)}>{selectedOrder.fulfillmentStatus}</em>
            </div>

            <div className="admin-order-detail-layout">
              <div className="admin-detail-grid">
                <span><small>Customer</small><strong>{selectedOrder.customer}</strong></span>
                <span><small>User ID</small><strong>{selectedOrder.userId}</strong></span>
                <span><small>Email</small><strong>{selectedOrder.email}</strong></span>
                <span><small>Payment Method</small><strong>{selectedOrder.paymentMethod}</strong></span>
                <span><small>Payment Status</small><strong>{selectedOrder.paymentStatus}</strong></span>
                <span><small>Order Total</small><strong>${selectedOrder.total.toFixed(2)}</strong></span>
                <span className="admin-wide-field"><small>Billing Address</small><strong>{selectedOrder.address}</strong></span>
              </div>

              <div className="admin-order-items">
                <strong>Items</strong>
                {selectedOrder.items.map((item) => (
                  <div key={item.title}>
                    <span><strong>{item.title}</strong><small>Quantity {item.quantity}</small></span>
                    <em>${(item.price * item.quantity).toFixed(2)}</em>
                  </div>
                ))}
              </div>
            </div>

            <div className="admin-order-actions">
              <label>
                Fulfilment Status
                <select value={draftStatus} onChange={(event) => setDraftStatus(event.target.value)} aria-label="Update order status">
                  {ORDER_STATUSES.map((status) => <option key={status}>{status}</option>)}
                </select>
              </label>
              <label>
                Admin Note
                <textarea
                  value={adminNote}
                  onChange={(event) => setAdminNote(event.target.value)}
                  rows="3"
                  placeholder="Internal note about this order"
                />
              </label>
              {message && <div className="admin-form-message" role="status">{message}</div>}
              <div className="admin-form-actions">
                <button className="primary-button" type="button" onClick={saveOrder}>Save Order</button>
                {selectedOrder.fulfillmentStatus === 'Refund Requested' && (
                  <button type="button" onClick={() => navigate('admin-refund-management')}>Review Refund</button>
                )}
              </div>
            </div>
          </section>
        </>
      )}
    </AdminShell>
  );
}
