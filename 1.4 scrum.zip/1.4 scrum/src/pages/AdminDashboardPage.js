import { useMemo, useState } from 'react';
import AdminShell from '../components/AdminShell';
import { adminOrders, adminRefunds, adminUsers } from '../config/adminData';

function AdminMetricCard({ label, value, hint, onClick }) {
  return (
    <article className="admin-metric-card">
      <strong>{label}</strong>
      <span>{value}</span>
      <small>{hint}</small>
      {onClick && <button type="button" onClick={onClick}>View details</button>}
    </article>
  );
}

function statusClass(status) {
  if (status === 'Completed') return 'status-paid';
  if (status === 'Cancelled' || status === 'Refunded') return 'status-rejected';
  return 'status-warning';
}

export default function AdminDashboardPage({ navigate, products }) {
  const [search, setSearch] = useState('');

  const metrics = useMemo(() => {
    const paidOrders = adminOrders.filter((order) => (
      order.paymentStatus === 'Paid' && order.fulfillmentStatus !== 'Refunded'
    ));

    return {
      sales: paidOrders.reduce((sum, order) => sum + order.total, 0),
      users: adminUsers.length,
      products: products.length,
      refunds: adminRefunds.filter((refund) => refund.status === 'Pending').length,
    };
  }, [products.length]);

  const chartData = useMemo(() => {
    const dates = ['07-12', '07-13', '07-14', '07-15', '07-16', '07-17', '07-18'];
    const totals = dates.map((date) => adminOrders
      .filter((order) => order.date.endsWith(date) && order.paymentStatus === 'Paid')
      .reduce((sum, order) => sum + order.total, 0));
    const maximum = Math.max(...totals, 1);

    return dates.map((date, index) => ({
      label: date,
      total: totals[index],
      height: Math.max(8, Math.round((totals[index] / maximum) * 100)),
    }));
  }, []);

  const recentOrders = useMemo(() => {
    const query = search.trim().toLowerCase();
    return [...adminOrders]
      .sort((left, right) => right.date.localeCompare(left.date))
      .filter((order) => !query || [
        order.id,
        order.customer,
        order.email,
        order.fulfillmentStatus,
      ].some((value) => String(value).toLowerCase().includes(query)))
      .slice(0, 4);
  }, [search]);

  return (
    <AdminShell
      title="Admin Dashboard"
      current="admin-dashboard"
      navigate={navigate}
      searchValue={search}
      onSearchChange={setSearch}
      searchPlaceholder="Search recent orders"
    >
      <div className="admin-metrics">
        <AdminMetricCard
          label="Paid Revenue"
          value={`$${metrics.sales.toFixed(2)}`}
          hint="Excludes refunded orders"
          onClick={() => navigate('admin-order-management')}
        />
        <AdminMetricCard
          label="Total Users"
          value={metrics.users}
          hint={`${adminUsers.filter((user) => user.status === 'Active').length} active`}
          onClick={() => navigate('admin-user-management')}
        />
        <AdminMetricCard
          label="Total Products"
          value={metrics.products}
          hint="Current catalogue"
          onClick={() => navigate('admin-product-management')}
        />
        <AdminMetricCard
          label="Pending Refunds"
          value={metrics.refunds}
          hint="Waiting for review"
          onClick={() => navigate('admin-refund-management')}
        />
      </div>

      <section className="admin-chart-card admin-sales-chart" aria-label="Seven day paid sales">
        <div className="admin-chart-heading">
          <div>
            <span className="eyebrow">Revenue trend</span>
            <h2>Paid sales</h2>
          </div>
          <span>12–18 Jul 2026</span>
        </div>
        <div className="admin-chart-bars">
          {chartData.map((item) => (
            <div key={item.label}>
              <span
                style={{ height: `${item.height}%` }}
                title={`${item.label}: $${item.total.toFixed(2)}`}
              />
              <small>{item.label}</small>
            </div>
          ))}
        </div>
      </section>

      <section className="admin-panel">
        <div className="admin-panel-heading admin-dashboard-heading">
          <div>
            <span className="eyebrow">Recent activity</span>
            <h2>Recent orders</h2>
          </div>
          <button type="button" onClick={() => navigate('admin-order-management')}>View all orders</button>
        </div>
        <div className="admin-table admin-dashboard-table" aria-label="Recent orders table">
          <div className="admin-table-row admin-table-head">
            <strong>Order ID</strong>
            <strong>Customer</strong>
            <strong>Total</strong>
            <strong>Status</strong>
            <strong>Action</strong>
          </div>
          {recentOrders.map((order) => (
            <div className="admin-table-row" key={order.id}>
              <span>{order.id}</span>
              <span className="admin-customer-cell">
                <strong>{order.customer}</strong>
                <small>{order.date}</small>
              </span>
              <span>${order.total.toFixed(2)}</span>
              <span><em className={statusClass(order.fulfillmentStatus)}>{order.fulfillmentStatus}</em></span>
              <button
                type="button"
                onClick={() => navigate(
                  order.fulfillmentStatus === 'Refund Requested'
                    ? 'admin-refund-management'
                    : 'admin-order-management'
                )}
              >
                {order.fulfillmentStatus === 'Refund Requested' ? 'Review' : 'Manage'}
              </button>
            </div>
          ))}
          {!recentOrders.length && <div className="admin-empty-row">No recent orders match your search.</div>}
        </div>
      </section>

      <section className="admin-dashboard-actions" aria-label="Quick actions">
        <button type="button" onClick={() => navigate('admin-product-management')}>
          <strong>Add or edit products</strong><span>Manage the digital catalogue</span>
        </button>
        <button type="button" onClick={() => navigate('admin-refund-management')}>
          <strong>Review refunds</strong><span>{metrics.refunds} requests are pending</span>
        </button>
        <button type="button" onClick={() => navigate('admin-user-management')}>
          <strong>Manage users</strong><span>Review access and account status</span>
        </button>
      </section>
    </AdminShell>
  );
}
