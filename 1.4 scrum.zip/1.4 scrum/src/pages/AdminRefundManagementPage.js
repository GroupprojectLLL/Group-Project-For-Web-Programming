import { useMemo, useState } from 'react';
import AdminShell from '../components/AdminShell';
import { adminRefunds } from '../config/adminData';

const ALL_STATUSES = 'All';

function statusClass(status) {
  if (status === 'Approved') return 'status-paid';
  if (status === 'Rejected') return 'status-rejected';
  return 'status-warning';
}

export default function AdminRefundManagementPage({ navigate }) {
  const [refunds, setRefunds] = useState(() => (
    adminRefunds.map((refund) => ({ ...refund, reviewedAt: '', adminNote: '' }))
  ));
  const [selectedRefundId, setSelectedRefundId] = useState(adminRefunds[0]?.id || '');
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState(ALL_STATUSES);
  const [dateFilter, setDateFilter] = useState('');
  const [decision, setDecision] = useState('Allow Refund');
  const [adminNote, setAdminNote] = useState('');
  const [message, setMessage] = useState('');

  const selectedRefund = refunds.find((refund) => refund.id === selectedRefundId) || refunds[0];

  const filteredRefunds = useMemo(() => {
    const query = search.trim().toLowerCase();

    return refunds.filter((refund) => {
      const matchesSearch = !query || [
        refund.id,
        refund.orderId,
        refund.userId,
        refund.productId,
        refund.reason,
      ].some((value) => String(value || '').toLowerCase().includes(query));
      const matchesStatus = statusFilter === ALL_STATUSES || refund.status === statusFilter;
      const matchesDate = !dateFilter || refund.requestedAt === dateFilter;

      return matchesSearch && matchesStatus && matchesDate;
    });
  }, [dateFilter, refunds, search, statusFilter]);

  const counts = useMemo(() => ({
    Pending: refunds.filter((refund) => refund.status === 'Pending').length,
    Approved: refunds.filter((refund) => refund.status === 'Approved').length,
    Rejected: refunds.filter((refund) => refund.status === 'Rejected').length,
  }), [refunds]);

  function reviewRefund(refund) {
    setSelectedRefundId(refund.id);
    setDecision(refund.status === 'Rejected' ? 'Reject Refund' : 'Allow Refund');
    setAdminNote(refund.adminNote || '');
    setMessage('');
  }

  function clearFilters() {
    setSearch('');
    setStatusFilter(ALL_STATUSES);
    setDateFilter('');
  }

  function submitDecision() {
    if (!selectedRefund) return;

    const nextStatus = decision === 'Allow Refund' ? 'Approved' : 'Rejected';
    const note = adminNote.trim();

    if (nextStatus === 'Rejected' && !note) {
      setMessage('Please add an admin note explaining why the refund is rejected.');
      return;
    }

    setRefunds((items) => items.map((refund) => (
      refund.id === selectedRefund.id
        ? {
          ...refund,
          status: nextStatus,
          adminNote: note,
          reviewedAt: new Date().toLocaleString(),
        }
        : refund
    )));
    setMessage(`${selectedRefund.id} has been ${nextStatus.toLowerCase()}.`);
  }

  return (
    <AdminShell
      title="Admin Refund Management | Current: Refunds"
      current="admin-refund-management"
      navigate={navigate}
      searchValue={search}
      onSearchChange={setSearch}
      searchPlaceholder="Search refunds"
    >
      <div className="admin-refund-summary" aria-label="Refund summary">
        <article><span>Pending</span><strong>{counts.Pending}</strong></article>
        <article><span>Approved</span><strong>{counts.Approved}</strong></article>
        <article><span>Rejected</span><strong>{counts.Rejected}</strong></article>
      </div>

      <div className="admin-section-label">Refund Requests</div>
      <div className="admin-filter-bar">
        <label>
          Search
          <input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            aria-label="Search refunds"
            placeholder="Refund, order or user ID"
          />
        </label>
        <label>
          Status
          <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
            <option>All</option>
            <option>Pending</option>
            <option>Approved</option>
            <option>Rejected</option>
          </select>
        </label>
        <label>
          Request Date
          <input
            type="text"
            value={dateFilter}
            onChange={(event) => setDateFilter(event.target.value)}
            aria-label="Request date"
            placeholder="YYYY-MM-DD"
            inputMode="numeric"
            pattern="\d{4}-\d{2}-\d{2}"
            maxLength="10"
          />
        </label>
        <button type="button" onClick={clearFilters}>Clear Filters</button>
        <span className="admin-result-count">{filteredRefunds.length} result{filteredRefunds.length === 1 ? '' : 's'}</span>
      </div>

      <div className="admin-table admin-refund-table" aria-label="Refund requests table">
        <div className="admin-table-row admin-table-head">
          <strong>Refund ID</strong>
          <strong>Order ID</strong>
          <strong>User ID</strong>
          <strong>Reason</strong>
          <strong>Amount</strong>
          <strong>Status</strong>
          <strong>Action</strong>
        </div>
        {filteredRefunds.map((refund) => (
          <div
            className={`admin-table-row ${selectedRefund?.id === refund.id ? 'is-selected' : ''}`}
            key={refund.id}
          >
            <span>{refund.id}</span>
            <span>{refund.orderId}</span>
            <span>{refund.userId}</span>
            <span>{refund.reason}</span>
            <span>${refund.amount.toFixed(2)}</span>
            <span><em className={statusClass(refund.status)}>{refund.status}</em></span>
            <button type="button" onClick={() => reviewRefund(refund)}>
              {refund.status === 'Pending' ? 'Review' : 'View'}
            </button>
          </div>
        ))}
        {!filteredRefunds.length && (
          <div className="admin-empty-row">
            No refund requests match the current filters.
          </div>
        )}
      </div>

      {selectedRefund && (
        <>
          <div className="admin-section-label">Refund Review Detail</div>
          <section className="admin-panel admin-detail-panel">
            <div className="admin-review-heading">
              <div>
                <span className="eyebrow">Selected request</span>
                <h2>{selectedRefund.id}</h2>
              </div>
              <em className={statusClass(selectedRefund.status)}>{selectedRefund.status}</em>
            </div>
            <div className="admin-detail-grid">
              <span><small>Refund ID</small><strong>{selectedRefund.id}</strong></span>
              <span><small>Order ID</small><strong>{selectedRefund.orderId}</strong></span>
              <span><small>Refund Person ID</small><strong>{selectedRefund.userId}</strong></span>
              <span><small>Product ID</small><strong>{selectedRefund.productId}</strong></span>
              <span><small>Refund Reason</small><strong>{selectedRefund.reason}</strong></span>
              <span><small>Product Usage Status</small><strong>{selectedRefund.usage}</strong></span>
              <span><small>Payment Status</small><strong>{selectedRefund.paymentStatus}</strong></span>
              <span><small>Refund Amount</small><strong>${selectedRefund.amount.toFixed(2)}</strong></span>
              {selectedRefund.reviewedAt && (
                <span className="admin-wide-field">
                  <small>Last Reviewed</small>
                  <strong>{selectedRefund.reviewedAt}</strong>
                </span>
              )}
            </div>
            <div className="admin-decision-box">
              <strong>Admin Decision</strong>
              <label>
                <input
                  type="radio"
                  name="refundDecision"
                  checked={decision === 'Allow Refund'}
                  onChange={() => setDecision('Allow Refund')}
                />
                Allow Refund
              </label>
              <label>
                <input
                  type="radio"
                  name="refundDecision"
                  checked={decision === 'Reject Refund'}
                  onChange={() => setDecision('Reject Refund')}
                />
                Reject Refund
              </label>
              <label className="admin-wide-field">
                Admin Note {decision === 'Reject Refund' && <small>(required for rejection)</small>}
                <textarea
                  rows="3"
                  value={adminNote}
                  onChange={(event) => setAdminNote(event.target.value)}
                  placeholder="Add review note"
                />
              </label>
              {message && (
                <div className={`admin-form-message admin-wide-field ${message.startsWith('Please') ? 'is-error' : ''}`} role="status">
                  {message}
                </div>
              )}
              <button className="primary-button" type="button" onClick={submitDecision}>
                Submit Decision
              </button>
            </div>
          </section>
        </>
      )}
    </AdminShell>
  );
}
