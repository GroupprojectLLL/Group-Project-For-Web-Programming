import { fireEvent, render, screen, within } from '@testing-library/react';
import AdminProductManagementPage from './AdminProductManagementPage';

const products = [
  { id: 1, title: 'Test Game', category: 'Games', type: 'Action', price: 12, description: 'Game description', art: 'nebula' },
  { id: 2, title: 'Test Book', category: 'Books', type: 'Fiction', price: 8, description: 'Book description', art: 'archive' },
];

describe('AdminProductManagementPage', () => {
  test('filters products by search and category', () => {
    render(<AdminProductManagementPage navigate={jest.fn()} products={products} />);

    fireEvent.change(screen.getByLabelText('Search product'), { target: { value: 'Book' } });
    const table = screen.getByText('Product List').parentElement.querySelector('.admin-product-table');

    expect(within(table).getByText('Test Book', { selector: 'span' })).toBeInTheDocument();
    expect(within(table).queryByText('Test Game')).not.toBeInTheDocument();
  });

  test('validates asset URLs', () => {
    render(<AdminProductManagementPage navigate={jest.fn()} products={products} />);

    fireEvent.change(screen.getByPlaceholderText('https://example.com/cover.jpg'), { target: { value: 'not-a-url' } });
    fireEvent.click(screen.getByRole('button', { name: 'Save Product' }));

    expect(screen.getByRole('status')).toHaveTextContent('valid http or https URL');
  });

  test('adds a product and persists bound asset fields', () => {
    render(<AdminProductManagementPage navigate={jest.fn()} products={products} />);

    fireEvent.click(screen.getByRole('button', { name: 'Add New Product' }));
    const titleInput = screen.getByText('Product Title').querySelector('input');
    fireEvent.change(titleInput, { target: { value: 'New Digital Game' } });
    fireEvent.change(screen.getByPlaceholderText('https://example.com/cover.jpg'), {
      target: { value: 'https://example.com/game.jpg' },
    });
    fireEvent.change(screen.getByPlaceholderText('https://example.com/download'), {
      target: { value: 'https://example.com/game.zip' },
    });
    fireEvent.click(screen.getByRole('button', { name: 'Add Product' }));

    expect(screen.getByRole('status')).toHaveTextContent('New product has been added locally');
    expect(screen.getByText('New Digital Game', { selector: '.admin-product-table .admin-table-row > span' })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Preview image' })).toHaveAttribute('href', 'https://example.com/game.jpg');
  });
});
