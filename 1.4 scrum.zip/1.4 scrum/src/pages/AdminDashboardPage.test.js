import { fireEvent, render, screen, within } from '@testing-library/react';
import AdminDashboardPage from './AdminDashboardPage';

const products = [{ id: 1 }, { id: 2 }, { id: 3 }];

describe('AdminDashboardPage', () => {
  test('calculates dashboard metrics from admin data', () => {
    render(<AdminDashboardPage navigate={jest.fn()} products={products} />);

    expect(screen.getByText('$69.96')).toBeInTheDocument();
    const userCard = screen.getByText('Total Users').closest('.admin-metric-card');
    const productCard = screen.getByText('Total Products').closest('.admin-metric-card');
    const refundCard = screen.getByText('Pending Refunds').closest('.admin-metric-card');
    expect(within(userCard).getByText('4')).toBeInTheDocument();
    expect(within(productCard).getByText('3')).toBeInTheDocument();
    expect(within(refundCard).getByText('2')).toBeInTheDocument();
  });

  test('filters recent orders using the dashboard search', () => {
    render(<AdminDashboardPage navigate={jest.fn()} products={products} />);

    fireEvent.change(screen.getByLabelText('Search admin records'), { target: { value: 'Jamie' } });

    const table = screen.getByLabelText('Recent orders table');
    expect(within(table).getByText('ORD-1004')).toBeInTheDocument();
    expect(within(table).queryByText('ORD-1001')).not.toBeInTheDocument();
  });

  test('routes refund requests to refund management', () => {
    const navigate = jest.fn();
    render(<AdminDashboardPage navigate={navigate} products={products} />);

    const table = screen.getByLabelText('Recent orders table');
    const refundRow = within(table).getByText('ORD-1002').closest('.admin-table-row');
    fireEvent.click(within(refundRow).getByRole('button', { name: 'Review' }));

    expect(navigate).toHaveBeenCalledWith('admin-refund-management');
  });
});
