import { fireEvent, render, screen, within } from '@testing-library/react';
import AdminRefundManagementPage from './AdminRefundManagementPage';

describe('AdminRefundManagementPage', () => {
  test('filters refund requests by status', () => {
    render(<AdminRefundManagementPage navigate={jest.fn()} />);

    fireEvent.change(screen.getByLabelText('Status'), { target: { value: 'Approved' } });

    const refundTable = screen.getByLabelText('Refund requests table');
    expect(within(refundTable).getByText('RF-203')).toBeInTheDocument();
    expect(within(refundTable).queryByText('RF-201')).not.toBeInTheDocument();
    expect(screen.getByText('1 result')).toBeInTheDocument();
  });

  test('requires a note when rejecting a refund', () => {
    render(<AdminRefundManagementPage navigate={jest.fn()} />);

    fireEvent.click(screen.getByLabelText('Reject Refund'));
    fireEvent.click(screen.getByRole('button', { name: 'Submit Decision' }));

    expect(screen.getByRole('status')).toHaveTextContent('Please add an admin note');
  });

  test('uses a consistent date format and filters by request date', () => {
    render(<AdminRefundManagementPage navigate={jest.fn()} />);

    const dateInput = screen.getByLabelText('Request date');
    expect(dateInput).toHaveAttribute('placeholder', 'YYYY-MM-DD');
    fireEvent.change(dateInput, { target: { value: '2026-07-10' } });

    const refundTable = screen.getByLabelText('Refund requests table');
    expect(within(refundTable).getByText('RF-203')).toBeInTheDocument();
    expect(within(refundTable).queryByText('RF-201')).not.toBeInTheDocument();
  });

  test('submits and persists a refund decision in the table', () => {
    render(<AdminRefundManagementPage navigate={jest.fn()} />);

    fireEvent.click(screen.getByLabelText('Reject Refund'));
    fireEvent.change(screen.getByPlaceholderText('Add review note'), {
      target: { value: 'The product has already been used.' },
    });
    fireEvent.click(screen.getByRole('button', { name: 'Submit Decision' }));

    const refundTable = screen.getByLabelText('Refund requests table');
    const refundRow = within(refundTable).getByText('RF-201').closest('.admin-table-row');
    expect(within(refundRow).getByText('Rejected')).toBeInTheDocument();
    expect(screen.getByRole('status')).toHaveTextContent('RF-201 has been rejected');
  });
});
