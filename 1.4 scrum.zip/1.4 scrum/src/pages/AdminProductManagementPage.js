import { useEffect, useMemo, useRef, useState } from 'react';
import ProductArt from '../components/ProductArt';
import { products as demoProducts } from '../data';
import AdminShell from '../components/AdminShell';

export default function AdminProductManagementPage({ navigate, products }) {
  const adminProducts = useMemo(() => (
    (products.length ? products : demoProducts).map((product, index) => ({
      ...product,
      adminStatus: index % 4 === 3 ? 'Hidden' : 'Active',
    }))
  ), [products]);
  const [managedProducts, setManagedProducts] = useState(adminProducts);
  const [productSearch, setProductSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [selectedProduct, setSelectedProduct] = useState(adminProducts[0]);
  const [formProduct, setFormProduct] = useState(adminProducts[0]);
  const [formMode, setFormMode] = useState('edit');
  const [formMessage, setFormMessage] = useState('');
  const formRef = useRef(null);

  useEffect(() => {
    setManagedProducts(adminProducts);
    setSelectedProduct(adminProducts[0] || null);
    setFormProduct(adminProducts[0] || createBlankProduct());
    setFormMode(adminProducts[0] ? 'edit' : 'new');
  }, [adminProducts]);

  const filteredProducts = useMemo(() => (
    managedProducts.filter((product) => {
      const searchText = productSearch.trim().toLowerCase();
      const matchesSearch = !searchText
        || String(product.title || '').toLowerCase().includes(searchText)
        || String(product.category || '').toLowerCase().includes(searchText)
        || String(product.type || '').toLowerCase().includes(searchText);
      const matchesCategory = categoryFilter === 'All' || product.category === categoryFilter;
      const matchesStatus = statusFilter === 'All' || product.adminStatus === statusFilter;

      return matchesSearch && matchesCategory && matchesStatus;
    })
  ), [managedProducts, categoryFilter, productSearch, statusFilter]);
  const productCounts = useMemo(() => ({
    total: managedProducts.length,
    active: managedProducts.filter((product) => product.adminStatus === 'Active').length,
    hidden: managedProducts.filter((product) => product.adminStatus === 'Hidden').length,
  }), [managedProducts]);

  function scrollToForm() {
    window.setTimeout(() => {
      formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 0);
  }

  function createBlankProduct() {
    return {
      id: `new-${Date.now()}`,
      title: '',
      category: 'Games',
      type: 'General',
      price: 0,
      oldPrice: 0,
      rating: 4.5,
      reviews: 0,
      art: 'nebula',
      description: '',
      imageUrl: '',
      accessUrl: '',
      creator: '',
      publisher: '',
      format: '',
      adminStatus: 'Active',
    };
  }

  function chooseProduct(product) {
    setSelectedProduct(product);
    setFormProduct({ ...product });
    setFormMode('edit');
    setFormMessage('');
  }

  function addNewProduct() {
    const blankProduct = createBlankProduct();
    setSelectedProduct(null);
    setFormProduct(blankProduct);
    setFormMode('new');
    setFormMessage('');
    scrollToForm();
  }

  function updateForm(field, value) {
    setFormProduct((product) => ({ ...product, [field]: value }));
  }

  function saveProduct() {
    const title = formProduct.title.trim();
    const price = Number(formProduct.price);

    if (!title) {
      setFormMessage('Please enter a product title before saving.');
      return;
    }
    if (!Number.isFinite(price) || price < 0) {
      setFormMessage('Please enter a valid product price.');
      return;
    }
    if (formProduct.imageUrl && !/^https?:\/\//i.test(formProduct.imageUrl)) {
      setFormMessage('Cover image must be a valid http or https URL.');
      return;
    }
    if (formProduct.accessUrl && !/^https?:\/\//i.test(formProduct.accessUrl)) {
      setFormMessage('Digital access link must be a valid http or https URL.');
      return;
    }

    const productToSave = {
      ...formProduct,
      title,
      type: formProduct.type || 'General',
      price,
      oldPrice: Number(formProduct.oldPrice || formProduct.price || 0),
      description: formProduct.description.trim() || 'No description is available for this product.',
      imageUrl: formProduct.imageUrl?.trim() || '',
      accessUrl: formProduct.accessUrl?.trim() || '',
      creator: formProduct.creator?.trim() || '',
      publisher: formProduct.publisher?.trim() || '',
      format: formProduct.format?.trim() || '',
    };

    if (formMode === 'new') {
      setManagedProducts((items) => [productToSave, ...items]);
      setSelectedProduct(productToSave);
      setFormProduct(productToSave);
      setFormMode('edit');
      setFormMessage('New product has been added locally.');
      return;
    }

    setManagedProducts((items) => (
      items.map((item) => (String(item.id) === String(productToSave.id) ? productToSave : item))
    ));
    setSelectedProduct(productToSave);
    setFormProduct(productToSave);
    setFormMessage('Product changes have been saved locally.');
  }

  function deleteProduct(productId = formProduct?.id) {
    if (!productId) return;

    const nextItems = managedProducts.filter((item) => String(item.id) !== String(productId));
    const nextSelected = nextItems[0] || createBlankProduct();

    setManagedProducts(nextItems);
    setSelectedProduct(nextItems[0] || null);
    setFormProduct(nextSelected);
    setFormMode(nextItems[0] ? 'edit' : 'new');
    setFormMessage(nextItems[0] ? 'Product has been deleted locally.' : 'Product has been deleted. You can add a new one.');
  }

  function cancelEdit() {
    const fallbackProduct = selectedProduct || managedProducts[0] || createBlankProduct();
    setFormProduct({ ...fallbackProduct });
    setFormMode(selectedProduct || managedProducts[0] ? 'edit' : 'new');
    setFormMessage('Changes have been cancelled.');
  }

  return (
    <AdminShell
      title="Admin Product Management | Current: Products"
      current="admin-product-management"
      navigate={navigate}
      searchValue={productSearch}
      onSearchChange={setProductSearch}
      searchPlaceholder="Search products"
    >
      <div className="admin-product-summary" aria-label="Product summary">
        <article><span>Total Products</span><strong>{productCounts.total}</strong></article>
        <article><span>Active</span><strong>{productCounts.active}</strong></article>
        <article><span>Hidden</span><strong>{productCounts.hidden}</strong></article>
      </div>

      <div className="admin-section-label">Product List</div>
      <div className="admin-filter-bar">
        <label>Search Product <input value={productSearch} onChange={(event) => setProductSearch(event.target.value)} aria-label="Search product" /></label>
        <label>Category <select value={categoryFilter} onChange={(event) => setCategoryFilter(event.target.value)}><option>All</option><option value="Books">E-books</option><option>Games</option><option>Movies & TV</option></select></label>
        <label>Status <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}><option>All</option><option>Active</option><option>Hidden</option></select></label>
        <button type="button" onClick={addNewProduct}>Add New Product</button>
      </div>

      <div className="admin-table admin-product-table">
        <div className="admin-table-row admin-table-head">
          <strong>ID</strong>
          <strong>Cover</strong>
          <strong>Title</strong>
          <strong>Category</strong>
          <strong>Price</strong>
          <strong>Status</strong>
          <strong>Actions</strong>
        </div>
        {filteredProducts.map((product, index) => (
          <div className="admin-table-row" key={product.id}>
            <span>P{String(product.id || index + 101).padStart(3, '0')}</span>
            <ProductArt product={product} className="admin-cover" />
            <span>{product.title}</span>
            <span>{product.category}</span>
            <span>${Number(product.price || 0).toFixed(2)}</span>
            <span><em className={product.adminStatus === 'Active' ? 'status-paid' : 'status-warning'}>{product.adminStatus}</em></span>
            <span className="admin-row-actions">
              <button type="button" onClick={() => chooseProduct(product)}>View</button>
              <button type="button" onClick={() => { chooseProduct(product); scrollToForm(); }}>Edit</button>
              <button type="button" onClick={() => deleteProduct(product.id)}>Delete</button>
            </span>
          </div>
        ))}
        {!filteredProducts.length && (
          <div className="admin-empty-row">
            No products match the current search or filter.
          </div>
        )}
      </div>

      <div className="admin-section-label" ref={formRef}>Add / Edit Product Form</div>
      <section className="admin-panel admin-form-panel">
        <div className="admin-form-grid">
          <label>Product Title <input value={formProduct?.title || ''} onChange={(event) => updateForm('title', event.target.value)} /></label>
          <label>Category <select value={formProduct?.category || 'Games'} onChange={(event) => updateForm('category', event.target.value)}><option value="Books">E-books</option><option>Games</option><option>Movies & TV</option></select></label>
          <label>Price <input type="number" min="0" step="0.01" value={formProduct?.price ?? 0} onChange={(event) => updateForm('price', event.target.value)} /></label>
          <label>Status <select value={formProduct?.adminStatus || 'Active'} onChange={(event) => updateForm('adminStatus', event.target.value)}><option>Active</option><option>Hidden</option></select></label>
          <label>Cover Image URL <input value={formProduct?.imageUrl || ''} onChange={(event) => updateForm('imageUrl', event.target.value)} placeholder="https://example.com/cover.jpg" /></label>
          <label>Digital File / Access Link <input value={formProduct?.accessUrl || ''} onChange={(event) => updateForm('accessUrl', event.target.value)} placeholder="https://example.com/download" /></label>
          <label>
            {formProduct?.category === 'Books' ? 'Author' : formProduct?.category === 'Games' ? 'Developer' : 'Director'}
            <input value={formProduct?.creator || ''} onChange={(event) => updateForm('creator', event.target.value)} />
          </label>
          <label>
            {formProduct?.category === 'Books' ? 'Publisher' : formProduct?.category === 'Games' ? 'Platform' : 'Duration'}
            <input value={formProduct?.publisher || ''} onChange={(event) => updateForm('publisher', event.target.value)} />
          </label>
          <label>
            {formProduct?.category === 'Books' ? 'Format' : formProduct?.category === 'Games' ? 'System Requirements' : 'Resolution'}
            <input value={formProduct?.format || ''} onChange={(event) => updateForm('format', event.target.value)} />
          </label>
          <label className="admin-wide-field">Description <textarea value={formProduct?.description || ''} onChange={(event) => updateForm('description', event.target.value)} rows="4" /></label>
        </div>
        {(formProduct?.imageUrl || formProduct?.accessUrl) && (
          <div className="admin-asset-preview">
            {formProduct.imageUrl && <span><small>Cover</small><a href={formProduct.imageUrl} target="_blank" rel="noreferrer">Preview image</a></span>}
            {formProduct.accessUrl && <span><small>Digital asset</small><a href={formProduct.accessUrl} target="_blank" rel="noreferrer">Open access link</a></span>}
          </div>
        )}
        {formMessage && <div className={`admin-form-message ${formMessage.startsWith('Please') || formMessage.includes('must be') ? 'is-error' : ''}`} role="status">{formMessage}</div>}
        <div className="admin-form-actions">
          <button className="primary-button" type="button" onClick={saveProduct}>{formMode === 'new' ? 'Add Product' : 'Save Product'}</button>
          <button type="button" onClick={cancelEdit}>Cancel</button>
          <button type="button" onClick={() => deleteProduct()}>Delete Product</button>
        </div>
      </section>
    </AdminShell>
  );
}
