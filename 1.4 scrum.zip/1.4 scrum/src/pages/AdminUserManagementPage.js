import { useMemo, useState } from 'react';
import AdminShell from '../components/AdminShell';
import { adminUsers } from '../config/adminData';

const ALL = 'All';

export default function AdminUserManagementPage({ navigate }) {
  const [users, setUsers] = useState(() => adminUsers.map((user) => ({ ...user })));
  const [selectedUserId, setSelectedUserId] = useState(adminUsers[0]?.id || '');
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState(ALL);
  const [roleFilter, setRoleFilter] = useState(ALL);
  const [message, setMessage] = useState('');

  const selectedUser = users.find((user) => user.id === selectedUserId) || users[0];

  const filteredUsers = useMemo(() => {
    const query = search.trim().toLowerCase();

    return users.filter((user) => {
      const matchesSearch = !query || [user.id, user.name, user.email]
        .some((value) => String(value || '').toLowerCase().includes(query));
      const matchesStatus = statusFilter === ALL || user.status === statusFilter;
      const matchesRole = roleFilter === ALL || user.role === roleFilter;

      return matchesSearch && matchesStatus && matchesRole;
    });
  }, [roleFilter, search, statusFilter, users]);

  const counts = useMemo(() => ({
    Total: users.length,
    Active: users.filter((user) => user.status === 'Active').length,
    Suspended: users.filter((user) => user.status === 'Suspended').length,
  }), [users]);

  function selectUser(user) {
    setSelectedUserId(user.id);
    setMessage('');
  }

  function clearFilters() {
    setSearch('');
    setStatusFilter(ALL);
    setRoleFilter(ALL);
  }

  function toggleUserStatus(userId = selectedUser?.id) {
    if (!userId) return;

    const user = users.find((item) => item.id === userId);
    if (!user) return;

    const nextStatus = user.status === 'Active' ? 'Suspended' : 'Active';
    setUsers((items) => items.map((item) => (
      item.id === userId ? { ...item, status: nextStatus } : item
    )));
    setSelectedUserId(userId);
    setMessage(`${user.name} is now ${nextStatus.toLowerCase()}.`);
  }

  function sendPasswordReset() {
    if (!selectedUser) return;
    setMessage(`Password reset link sent to ${selectedUser.email}.`);
  }

  return (
    <AdminShell
      title="Admin User Management | Current: Users"
      current="admin-user-management"
      navigate={navigate}
      searchValue={search}
      onSearchChange={setSearch}
      searchPlaceholder="Search users"
    >
      <div className="admin-user-summary" aria-label="User summary">
        <article><span>Total Users</span><strong>{counts.Total}</strong></article>
        <article><span>Active</span><strong>{counts.Active}</strong></article>
        <article><span>Suspended</span><strong>{counts.Suspended}</strong></article>
      </div>

      <div className="admin-section-label">User List</div>
      <div className="admin-filter-bar">
        <label>
          Search
          <input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            aria-label="Search users"
            placeholder="ID, name or email"
          />
        </label>
        <label>
          Status
          <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)} aria-label="User status">
            <option>All</option>
            <option>Active</option>
            <option>Suspended</option>
          </select>
        </label>
        <label>
          Role
          <select value={roleFilter} onChange={(event) => setRoleFilter(event.target.value)} aria-label="User role">
            <option>All</option>
            <option>Customer</option>
            <option>Employee</option>
            <option>Admin</option>
          </select>
        </label>
        <button type="button" onClick={clearFilters}>Clear Filters</button>
        <span className="admin-result-count">{filteredUsers.length} result{filteredUsers.length === 1 ? '' : 's'}</span>
      </div>

      <div className="admin-table admin-user-table" aria-label="User list table">
        <div className="admin-table-row admin-table-head">
          <strong>User ID</strong>
          <strong>Name</strong>
          <strong>Email</strong>
          <strong>Role</strong>
          <strong>Status</strong>
          <strong>Orders</strong>
          <strong>Actions</strong>
        </div>
        {filteredUsers.map((user) => (
          <div
            className={`admin-table-row ${selectedUser?.id === user.id ? 'is-selected' : ''}`}
            key={user.id}
          >
            <span>{user.id}</span>
            <span>{user.name}</span>
            <span>{user.email}</span>
            <span>{user.role}</span>
            <span>
              <em className={user.status === 'Active' ? 'status-paid' : 'status-rejected'}>
                {user.status}
              </em>
            </span>
            <span>{user.orders}</span>
            <span className="admin-row-actions">
              <button type="button" onClick={() => selectUser(user)}>View</button>
              <button type="button" onClick={() => toggleUserStatus(user.id)}>
                {user.status === 'Active' ? 'Disable' : 'Enable'}
              </button>
            </span>
          </div>
        ))}
        {!filteredUsers.length && (
          <div className="admin-empty-row">
            No users match the current search or filters.
          </div>
        )}
      </div>

      {selectedUser && (
        <>
          <div className="admin-section-label">User Detail Panel</div>
          <section className="admin-panel admin-detail-panel">
            <div className="admin-review-heading">
              <div>
                <span className="eyebrow">Selected user</span>
                <h2>{selectedUser.name}</h2>
              </div>
              <em className={selectedUser.status === 'Active' ? 'status-paid' : 'status-rejected'}>
                {selectedUser.status}
              </em>
            </div>
            <div className="admin-detail-grid">
              <span><small>User ID</small><strong>{selectedUser.id}</strong></span>
              <span><small>Name</small><strong>{selectedUser.name}</strong></span>
              <span><small>Email</small><strong>{selectedUser.email}</strong></span>
              <span><small>Role</small><strong>{selectedUser.role}</strong></span>
              <span><small>Status</small><strong>{selectedUser.status}</strong></span>
              <span><small>Registered Date</small><strong>{selectedUser.registered}</strong></span>
              <span><small>Total Orders</small><strong>{selectedUser.orders}</strong></span>
              <span><small>Total Spending</small><strong>${selectedUser.spending.toFixed(2)}</strong></span>
              <span><small>Refund Count</small><strong>{selectedUser.refunds}</strong></span>
            </div>
            {message && <div className="admin-form-message" role="status">{message}</div>}
            <div className="admin-form-actions">
              <button className="primary-button" type="button" onClick={() => navigate('order-history')}>
                View Orders
              </button>
              <button type="button" onClick={() => toggleUserStatus()}>
                {selectedUser.status === 'Active' ? 'Disable User' : 'Enable User'}
              </button>
              <button type="button" onClick={sendPasswordReset}>Send Reset Password Link</button>
            </div>
          </section>
        </>
      )}
    </AdminShell>
  );
}
