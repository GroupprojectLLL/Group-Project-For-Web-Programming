export const employeeMenuItems = [
  { label: 'Inventory Dashboard', page: 'employee-dashboard' },
  { label: 'Stock Management', page: 'employee-stock-management' },
  { label: 'Stock History', page: 'employee-stock-history' },
];

export const initialInventory = [
  { id: 'STK-101', sku: 'GAME-NEB-01', product: 'Nebula Drift', category: 'Games', available: 28, reserved: 4, reorderLevel: 10, updatedAt: '2026-07-18 09:30' },
  { id: 'STK-102', sku: 'BOOK-ARC-01', product: 'The Quiet Archive', category: 'Books', available: 8, reserved: 2, reorderLevel: 10, updatedAt: '2026-07-18 10:15' },
  { id: 'STK-103', sku: 'GAME-PIX-01', product: 'Pixel Kitchen', category: 'Games', available: 0, reserved: 0, reorderLevel: 8, updatedAt: '2026-07-18 11:40' },
  { id: 'STK-104', sku: 'MOV-CIN-01', product: 'Cinema Essentials', category: 'Movies & TV', available: 17, reserved: 3, reorderLevel: 6, updatedAt: '2026-07-18 13:05' },
  { id: 'STK-105', sku: 'GAME-SOL-01', product: 'Solar Tactics', category: 'Games', available: 5, reserved: 1, reorderLevel: 10, updatedAt: '2026-07-19 08:20' },
];

export const initialStockHistory = [
  { id: 'MOV-1001', stockId: 'STK-105', product: 'Solar Tactics', before: 12, after: 5, change: -7, reason: 'Customer orders fulfilled', employee: 'EMP-001', timestamp: '2026-07-19 08:20' },
  { id: 'MOV-1002', stockId: 'STK-102', product: 'The Quiet Archive', before: 4, after: 8, change: 4, reason: 'New licence batch received', employee: 'EMP-001', timestamp: '2026-07-18 10:15' },
];

export function getStockStatus(item) {
  if (item.available === 0) return 'Out of Stock';
  if (item.available <= item.reorderLevel) return 'Low Stock';
  return 'Available';
}
