import Icon from './Icon';
import { employeeMenuItems } from '../config/employeeData';

export default function EmployeeShell({
  title,
  current,
  navigate,
  searchValue = '',
  onSearchChange,
  searchPlaceholder = 'Search inventory',
  children,
}) {
  return (
    <main className="employee-page page-shell">
      <div className="employee-titlebar">
        <div><span>Employee Portal</span><strong>{title}</strong></div>
        <span className="employee-id">EMP-001</span>
      </div>
      <section className="employee-topbar">
        <label className="employee-search">
          <Icon name="search" size={16} />
          <input
            value={searchValue}
            onChange={(event) => onSearchChange?.(event.target.value)}
            placeholder={searchPlaceholder}
            aria-label="Search employee records"
          />
        </label>
      </section>
      <div className="employee-layout">
        <aside className="employee-sidebar">
          <span>Inventory Workspace</span>
          <div>
            {employeeMenuItems.map((item) => (
              <button
                className={current === item.page ? 'active' : ''}
                type="button"
                onClick={() => navigate(item.page)}
                key={item.page}
              >
                {item.label}
              </button>
            ))}
            <button type="button" onClick={() => navigate('home')}>Logout</button>
          </div>
        </aside>
        <section className="employee-content">{children}</section>
      </div>
    </main>
  );
}
